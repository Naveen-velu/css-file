<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Trello Board</title> 
        <link rel="stylesheet" href="css/page1.css">
		 <link rel="stylesheet" href="css/page.css">
        <link rel="stylesheet" href="https://great-learning.s3.ap-south-1.amazonaws.com/week-2/css/trello-dashboard.css"> 
     
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
		
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    </head>
    <body>
        <nav class="navbar">
            <ul class="menu">
                <li class="heads">
                    <i class="home fas fa-home"></i>
                </li>
                <li class="heads">
                    <i class="boards fas fa-th-list"></i>
                    Boards
                </li>
              
            </ul>
            <h3>
                Tralala
            </h3>
            <div class="actions">
                <span class="heads">
                    <i class="fas fa-plus" id="add-board"></i>
                </span>
                <span class="heads">
                    <i class="fas fa-user" id="profile-image"></i>
                </span>
            </div>
        </nav>
        <div class="board-container">
            <div class="board-menu">
                <div class="board-title">Frontend Training</div>
                <div class="board-show-menu heads">
                    <i class="fas fa-ellipsis-v"></i>
                    Show menu
                </div>
            </div>
            <div class="board">
                <div class="input-val-list-wrapper">
                    <div class="input-val-list">
                        <div class="title-name-container">
                            <h3 class="title-name">To Do</h3>
                            <span class="input-val-list-more heads">...</span>
                        </div>
                        <div class="input-val heads">
                            Learn HTML
                            <i class="input-val-edit fas fa-pencil-alt heads"></i>
                        </div>
                        <div class="input-val heads">
                            Learn CSS
                            <i class="input-val-edit fas fa-pencil-alt heads"></i>
                        </div>
                        <div class="input-val heads">
                            Learn JavaScript
                            <i class="input-val-edit fas fa-pencil-alt heads"></i>
                        </div>
                        <div class="add-card-message heads">+ Add another card</div>
                    </div>
                </div>
                <div class="input-val-list-wrapper">
                    <div class="input-val-list">
                        <div class="title-name-container">
                            <h3 class="title-name">Doing</h3>
                            <span class="input-val-list-more heads">...</span>
                        </div>
                        <div class="input-val heads">Prepare resume</div>
                        <div class="add-card-form">
                            <form>
                                <textarea rows="3" placeholder="Enter a title for this card..." class="full-width-input"></textarea>
                                <div class="add-card-form-actions">
                                    <button class="w3-bar-item w3-button w3-teal">Add Card</button>
                                    <i class="fas fa-2x fa-times add-card-cancel heads"></i>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="input-val-list-wrapper">
                    <div class="input-val-list">
                        <div class="title-name-container">
                            <h3 class="title-name">Testing/Verifying</h3>
                            <span class="input-val-list-more heads">...</span>
                        </div>
                        <div class="input-val heads">Twitter app frontend</div>
                        <div class="add-card-message heads">+ Add another card</div>
                    </div>
                </div>
                <div class="input-val-list-wrapper">
                    <div class="input-val-list">
                        <div class="title-name-container">
                            <h3 class="title-name">Deploying</h3>
                            <span class="input-val-list-more heads">...</span>
                        </div>
                        <div class="input-val heads">Twitter app backend</div>
                        <div class="add-card-message heads">+ Add another card</div>
                    </div>
                </div>
                <div class="input-val-list-wrapper">
                    <div class="input-val-list">
                        <div class="title-name-container">
                            <h3 class="title-name">Done</h3>
                            <span class="input-val-list-more heads">...</span>
                        </div>
                        <div class="add-card-message heads">+ Add card</div>
                    </div>
                </div>
                <div class="input-val-list-wrapper">
                    <div class="input-val-list">
                        <div class="add-list-message heads">+ Add another list</div>
                    </div>
                </div>
                <div class="input-val-list-wrapper">
                    <div class="input-val-list">
                        <div class="add-card-form">
                            <form>
                                <textarea rows="3" placeholder="Enter list title..." class="full-width-input"></textarea>
                                <div class="add-list-form-actions">
                                    <button class="w3-bar-item w3-button w3-teal">Add List</button>
                                    <i class="fas fa-2x fa-times add-list-cancel heads"></i>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>